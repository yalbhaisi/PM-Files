﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RemittaGateway.Models;
using RestSharp;

namespace RemittaGateway.Controllers
{
    public class RemittaGatewayController : ApiController
    {
        private RemittaGatewayBusLogic busLogic = new RemittaGatewayBusLogic();
        [HttpPost]
        [Route("api/CustomerValidation")]
        public CustomerInformationResponse CustomerValidation(CustomerInformationRequest Cust)
        {
            return busLogic.CustomerValidation(Cust);
        }

        [HttpGet]
        [Route("api/RemittaCustomerValidation")]
        public RemittaValidationResponse RemittaCustomerValidation(string uid, string sid)
        {
            return busLogic.RemittaCustomerValidation(uid, sid);
        }
        [HttpPost]
        [Route("api/RemittaPaymentNotification")]
        public string RemittaPaymentNotification(RemittaPaymentNotificationRequest RemPay)
        {
            return busLogic.RemittaPaymentNotification(RemPay);

        }
    }
}
