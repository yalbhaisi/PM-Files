﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class PaymentNotificationResponse
    {
        public List<RemittaGateway.Models.Pnr.Payment> Payments { get; set; }
    }
}