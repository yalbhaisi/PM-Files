﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class Item
    {
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public string Quantity { get; set; }
        public string Price { get; set; }
        public string Subtotal { get; set; }
        public string Tax { get; set; }
        public string Total { get; set; }
    }
}