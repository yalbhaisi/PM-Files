﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class PaymentNotificationRequest
    {
        public string ServiceUrl { get; set; }
        public string ServiceUsername { get; set; }
        public string ServicePassword { get; set; }
        public string FtpUrl { get; set; }
        public string FtpUsername { get; set; }
        public string FtpPassword { get; set; }
        public List<Payment> Payments { get; set; }
    }
}