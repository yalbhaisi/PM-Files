﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class Customer
    {
        public string Status { get; set; }
        public string CustReference { get; set; }
        public string CustomerReferenceAlternate { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string ThirdPartyCode { get; set; }
        public string Amount { get; set; }
        public List<Item> PaymentItems{ get; set; }
    }
}