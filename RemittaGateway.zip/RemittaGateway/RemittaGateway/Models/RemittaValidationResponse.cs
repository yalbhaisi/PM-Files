﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class RemittaValidationResponse
    {
        public string response { get; set; }
        public string uid { get; set; }
        public string sid { get; set; }
        public string amount { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
    }
}