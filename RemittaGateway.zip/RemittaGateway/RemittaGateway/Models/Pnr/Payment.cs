﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models.Pnr
{
    public class Payment
    {
        public string PaymentLogId { get; set; }
        public string Status { get; set; }
    }
}