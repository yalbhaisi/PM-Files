﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RestSharp;
namespace RemittaGateway.Models
{
    public class RemittaGatewayBusLogic
    {
        public CustomerInformationResponse CustomerValidation(CustomerInformationRequest Cust)
        {
            RestClient client = new RestClient("https://www.axamansard.com");
            var request = new RestRequest("/inflowcollection/ProcessPayDirectRequest", Method.POST, DataFormat.Xml);
            request.AddBody(Cust);
            var response = client.Execute<CustomerInformationResponse>(request);
            var customer = response.Data;
            return customer;
        }

        public PaymentNotificationResponse PaymentNotification(PaymentNotificationRequest PayRequest)
        {
            RestClient client = new RestClient("https://www.axamansard.com");
            var request = new RestRequest("/inflowcollection/ProcessPayDirectRequest", Method.POST, DataFormat.Xml);
            request.AddBody(PayRequest);
            var response = client.Execute<PaymentNotificationResponse>(request);
            var payment = response.Data;
            return payment;
        }

        public RemittaValidationResponse RemittaCustomerValidation(string uid, string sid)
        {
            var cust = new CustomerInformationRequest
            {
                CustReference = uid,
                MerchantReference = sid,
                FtpPassword = "",
                FtpUsername = "",
                PartyCode = "",
                PaymentItemCode = "",
                ServicePassword = "",
                ServiceUsername = ""
            };
            var custVal = this.CustomerValidation(cust);
            RemittaValidationResponse remitta = new RemittaValidationResponse
            {
                amount = "null",
                email = "null",
                name = "null",
                phoneNumber = "null",
                response = "not ok",
                uid = "null",
                sid = sid
            };
            Customer customer = new Customer();
            if(custVal != null)
            {
                var customers = custVal.Customers;
                foreach(Customer cst in customers)
                {
                    customer = cst;
                    break;
                }
                if(customer != null)
                {
                    var remit = new RemittaValidationResponse
                    {
                        amount = customer.Amount,
                        email = customer.Email,
                        name = customer.LastName +" "+customer.FirstName,
                        phoneNumber = customer.Phone,
                        response = "ok",
                        uid = customer.CustReference,
                        sid = sid
                    };
                    remitta = remit;
                }
                
                
            }
            return remitta;
        }

        public string RemittaPaymentNotification(RemittaPaymentNotificationRequest RemPay)
        {
            string resp = "“Not Ok";
            
            Payment Pay = new Payment
            {
                AlternateCustReference = "--N/A--",
                Amount = RemPay.amount,
                BankCode = "",
                BankName ="",
                BranchName = RemPay.branch,
                ChannelName = RemPay.channel,
                CollectionsAccount = "",
                CustomerAddress = "",
                CustomerName = RemPay.payerName,
                CustomerPhoneNumber = RemPay.payerPhoneNumber,
                CustReference = RemPay.rrr,
                DepositorName ="",
                DepositSlipNumber = "",
                FeeName = "",
                InstitutionId = "",
                InstitutionName = "",
                IsRepeated = false,
                IsReversal = false,
                Location = "",
                OriginalPaymentLogId = "",
                OriginalPaymentReference = "",
                OtherCustomerInfo = "",
                PaymentCurrency = "",
                PaymentDate = DateTime.ParseExact(RemPay.transactiondate,"dd/MM/yyyy",System.Globalization.CultureInfo.InvariantCulture),
                PaymentLogId = "",
                PaymentMethod = "",
                PaymentReference = "",

                
            };

            var customFields = RemPay.customFieldData;
            if(customFields != null)
            {
                if (customFields.ContainsKey("CollectionsAccount"))
                {
                    var value = customFields["CollectionsAccount"];
                    Pay.CollectionsAccount = value;
                }
                if (customFields.ContainsKey("ChannelName"))
                {
                    var value = customFields["ChannelName"];
                    Pay.ChannelName = value;
                }
                if (customFields.ContainsKey("CustomerAddress"))
                {
                    var value = customFields["CustomerAddress"];
                    Pay.CustomerAddress = value;
                }
            }
            
            var PayRequest = new PaymentNotificationRequest
            {
                FtpPassword = "",
                FtpUrl = "http://test.com/Payments/Interswitch/Notification_CPN.aspx",
                FtpUsername = "",
                ServicePassword = "",
                ServiceUrl = ""

            };
            return resp;
        }
    }
}