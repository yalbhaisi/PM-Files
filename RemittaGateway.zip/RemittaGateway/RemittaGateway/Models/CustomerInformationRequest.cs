﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class CustomerInformationRequest
    {
        public string MerchantReference { get; set; }
        public string CustReference { get; set; }
        public string PaymentItemCode { get; set; }
        public string PartyCode { get; set; }
        public string ServiceUsername { get; set; }
        public string ServicePassword { get; set; }
        public string FtpUsername { get; set; }
        public string FtpPassword { get; set; }
    }
}