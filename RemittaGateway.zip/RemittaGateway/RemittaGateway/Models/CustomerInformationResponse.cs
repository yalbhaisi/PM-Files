﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class CustomerInformationResponse
    {
        public string MerchantReference { get; set; }
        public List<Customer> Customers { get; set; }

    }
}