﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RemittaGateway.Models
{
    public class Payment
    {
        public bool IsRepeated { get; set; }
        public string ProductGroupCode { get; set; }
        public string PaymentLogId { get; set; }
        public string CustReference { get; set; }
        public string AlternateCustReference { get; set; }
        public double Amount { get; set; }
        public string PaymentStatus { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentReference { get; set; }
        public string TerminalId { get; set; }
        public string ChannelName { get; set; }
        public string Location { get; set; }
        public bool IsReversal { get; set; }
        public DateTime PaymentDate { get; set; }
        public DateTime SettlementDate { get; set; }
        public string InstitutionId { get; set; }
        public string InstitutionName { get; set; }
        public string BranchName { get; set; }
        public string BankName { get; set; }
        public string FeeName { get; set; } 
        public string CustomerName { get; set; }
        public string OtherCustomerInfo { get; set; }
        public string ReceiptNo { get; set; }
        public string CollectionsAccount { get; set; }
        public string ThirdPartyCode { get; set; }
        public List<PaymentItem> PaymentItems { get; set; }

        public string BankCode { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public string DepositorName { get; set; }
        public string DepositSlipNumber { get; set; }
        public string PaymentCurrency { get; set; }
        public string OriginalPaymentLogId { get; set; }
        public string OriginalPaymentReference{ get; set; }
        public string Teller { get; set; }
    }

    public class PaymentItem
    {
        public string ItemName { get; set; }
        public string  ItemCode { get; set; }
        public double  ItemAmount { get; set; }
        public string  LeadBankCode { get; set; }
        public string LeadBankCbnCode { get; set; }
        public string LeadBankName { get; set; }
        public string  CategoryCode { get; set; }
        public string CategoryName{ get; set; }
        public int ItemQuantity { get; set; }
    }
}