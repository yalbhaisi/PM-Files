﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMGateway.Models
{
    public class CaseVariables
    {
        public List<CaseVariable> caseVariable { get; set; }
    }
}