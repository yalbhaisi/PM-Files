﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMGateway.Models
{
    public class CreatePMCaseResponse
    {
        public string app_uid { get; set; }
        public string app_number { get; set; }
        public ErrorReport error { get; set; }

    }

    public class ErrorReport
    {
        public string code { get; set; }
        public string message { get; set; }
        public string error_description { get; set; }
    }
}