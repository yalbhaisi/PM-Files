﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMGateway.Models
{
    public class AccessTokenParams
    {
        public readonly string client_id = "ZSGGKJYFDOEIOBULDDQBCXYFTGENQMAQ";
        public readonly string client_secret = "1950141665a71887b3c8fd1019601832";
        public readonly string grant_type = "password";
        public readonly string scope = "*";
        public  string username = "webentry";
        public  string password = "Mansard01";
        public readonly string usr_uid = "6583285825a61c681b64ae4015270962";
        

        
    }
}