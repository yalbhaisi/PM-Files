﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMGateway.Models
{
    public class PMRequestParam
    {
        public string username { get; set; }
        public string name { get; set; }
        public string password { get; set; }
        public string app_uid { get; set; }
        public string pro_uid { get; set; }
        public string tas_uid { get; set; }
        public string del_index { get; set; }
        public CaseVariables caseVariables { get; set; }
    }
}