﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMGateway.Models
{
    public class PMServerParams
    {
        public static readonly string IPAddress = "http://192.168.0.21/";
        public static readonly string workspace = "workflow";

    }
}